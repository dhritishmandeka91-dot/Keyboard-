# Feature status
Legend: "Written" = source exists. NOTHING has been compiled or run yet (no Android SDK / network in the authoring
environment). The only executed check so far: Python contrast calculation of the 24 theme presets (all text pairs >= 4.5:1).

| Feature | Source | Runtime verified |
|---|---|---|
| InputMethodService, manifest, method.xml, QWERTY/symbols, shift/caps, backspace repeat, enter, space | Written | NOT TESTED |
| Hinglish -> English rewrite via local MediaPipe model (replaces text in field) | Written | NOT TESTED (needs your model + phone) |
| 6 writing modes | Written | NOT TESTED; quality unmeasured |
| Auto-rewrite (punctuation + idle delay, default 1.2 s), manual rewrite, undo, stale/recursion/duplicate guards | Written | NOT TESTED |
| Sensitive-field exclusion, privacy mode, AI off | Written | NOT TESTED |
| Model import / storage + RAM checks / progress / cancel / remove / test / low-memory unload | Written | NOT TESTED |
| Model download | NOT IMPLEMENTED (gated licences; app has no INTERNET permission by design) | - |
| 13 target languages with capability report | Written (conservative filename table) | NOT TESTED; per-language quality NOT measured |
| Language detection | PARTIAL (heuristic) | unit tests written, not run |
| Themes: Light/Dark/AMOLED/System + 24 presets, custom accent, key height, font scale, opacity | Written | NOT TESTED visually; contrast of presets verified by script |
| Haptics, sounds, reduced motion, one-handed (left/right) | Written | NOT TESTED |
| Floating keyboard | NOT IMPLEMENTED (no reliable Android API) | - |
| Word suggestions (built-in ~400 words, nothing learned), emoji suggestions + emoji panel | Written | NOT TESTED |
| Text shortcuts | Written | NOT TESTED |
| Clipboard history (memory only, opt-in, skips sensitive clips/fields) | Written | NOT TESTED |
| Autocorrect | NOT IMPLEMENTED on purpose (would corrupt Hinglish) | - |
| Swipe typing, voice typing, non-QWERTY layouts, RTL/CJK keyboards | NOT IMPLEMENTED | - |
| Quality probe (10 cases + latency) inside Settings | Written | NOT TESTED; run it on your phone with your model |
| JUnit tests (18) for sentence logic, sanitiser, detector, capability table, contrast | Written; run in CI after APK build | NOT RUN |
| Performance monitor | PARTIAL (last load / rewrite ms in Settings) | NOT TESTED |

## Added in the design/animation pass (all source-only, NOT COMPILED, NOT TESTED on a device)
| Feature | Source | Runtime verified |
|---|---|---|
| Pearl/ivory/cherry light design from the written brief (no image reference was received) | Written | NOT TESTED visually |
| Glossy two-layer keycaps (lip + gradient face + rim), key shape (rounded/pill/square) | Written | NOT TESTED |
| Frosted-look toolbar + expandable drawer (translucent fills; NOT a real blur) | Written | NOT TESTED |
| Spring key press (androidx.dynamicanimation), ripples, suggestion fade, drawer expand/collapse | Written | NOT TESTED |
| Busy pulse on Rewrite (only while inference runs), "Rewritten" confirmation, Undo pop-in | Written | NOT TESTED |
| In-text rewrite animation inside the other app's text field | NOT IMPLEMENTED (an IME cannot animate host text) | - |
| Animation off / subtle / lively; honours reduced-motion and system animator scale 0 | Written | NOT TESTED |
| Long-press alternates (accented letters, punctuation) via popup | Written | NOT TESTED (PopupWindow in IME may need device tuning) |
| Landscape key height, no fullscreen extract UI | Written | NOT TESTED |
| Onboarding with live enabled/selected status, collapsible cards, entrance animation | Written | NOT TESTED |
| Haptics/sound toggles | Written | NOT TESTED |
