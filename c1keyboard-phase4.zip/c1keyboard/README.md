# C1 Keyboard (phases 1-3)
Build: push to GitHub -> Actions -> "Build debug APK" -> download artifact `C1Keyboard-debug-apk`.
Statuses: see FEATURE_STATUS.md. NOT compiled or run in the authoring environment.
