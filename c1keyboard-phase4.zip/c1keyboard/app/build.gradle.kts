plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.c1keyboard.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.c1keyboard.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.2-phase2-3"
        ndk { abiFilters += listOf("arm64-v8a") }   // MediaPipe native libs: real phones only
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    // MediaPipe LLM Inference (documented version; API is in maintenance mode upstream)
    implementation("com.google.mediapipe:tasks-genai:0.10.14")
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")   // spring animations
    testImplementation("junit:junit:4.13.2")
}
