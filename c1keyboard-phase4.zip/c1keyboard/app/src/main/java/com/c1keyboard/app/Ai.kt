package com.c1keyboard.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.util.concurrent.Executors

interface LlmEngine {
    val isLoaded: Boolean
    fun load(path: String)
    fun generate(prompt: String): String
    fun close()
}

/** Real on-device inference through MediaPipe LLM Inference (CPU/GPU decided by the runtime). */
class MediaPipeEngine(private val ctx: Context) : LlmEngine {
    private var llm: LlmInference? = null
    override val isLoaded: Boolean get() = llm != null
    override fun load(path: String) {
        close()
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path).setMaxTokens(1024).setTopK(40).setTemperature(0.2f).setRandomSeed(7).build()
        llm = LlmInference.createFromOptions(ctx, opts)
    }
    override fun generate(prompt: String): String = llm!!.generateResponse(prompt)
    override fun close() { try { llm?.close() } catch (_: Throwable) {}; llm = null }
}

/**
 * Process-wide single inference worker (low priority thread). All engine access happens on that thread,
 * so the keyboard UI thread never blocks. Model is lazily loaded and unloaded when idle or on low memory.
 */
class AiRewriter private constructor(ctx: Context) {
    private val app = ctx.applicationContext
    private val models = ModelManager(app)
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "c1-ai").apply { priority = Thread.MIN_PRIORITY; isDaemon = true } }
    private var engine: LlmEngine? = null
    private var loadedPath: String? = null
    private val idleClose = Runnable { exec.execute { closeEngine() } }
    @Volatile var lastLoadMs = -1L; private set
    @Volatile var lastInferMs = -1L; private set

    private fun closeEngine() { engine?.close(); engine = null; loadedPath = null }

    private fun ensureLoaded(): LlmEngine {
        val f = models.installedFile() ?: throw IllegalStateException("No model installed")
        val e = engine
        if (e != null && e.isLoaded && loadedPath == f.absolutePath) return e
        closeEngine()
        val t0 = SystemClock.elapsedRealtime()
        val n = MediaPipeEngine(app); n.load(f.absolutePath)
        lastLoadMs = SystemClock.elapsedRealtime() - t0
        engine = n; loadedPath = f.absolutePath
        return n
    }

    fun release() { exec.execute { closeEngine() } }

    /** Returns a cancel function. A cancelled job is never delivered (and is skipped if still queued). */
    fun submit(prompt: String, cb: (Result<String>) -> Unit): () -> Unit {
        val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
        exec.execute {
            if (cancelled.get()) return@execute
            main.removeCallbacks(idleClose)
            val r = runCatching {
                val e = ensureLoaded()
                val t0 = SystemClock.elapsedRealtime()
                val out = e.generate(prompt)
                lastInferMs = SystemClock.elapsedRealtime() - t0
                out
            }
            if (r.isFailure) closeEngine()
            main.postDelayed(idleClose, 120_000)
            if (!cancelled.get()) main.post { if (!cancelled.get()) cb(r) }
        }
        return { cancelled.set(true) }
    }

    companion object {
        @Volatile private var inst: AiRewriter? = null
        fun get(ctx: Context): AiRewriter = inst ?: synchronized(this) { inst ?: AiRewriter(ctx).also { inst = it } }
    }
}
