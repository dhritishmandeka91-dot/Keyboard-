package com.c1keyboard.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import androidx.dynamicanimation.animation.SpringForce

/** The keyboard: glossy QWERTY, frosted AI toolbar + drawer, suggestions, emoji/clipboard panels, themes. */
class C1KeyboardService : InputMethodService(), RewriteController.Ui {

    private lateinit var settings: Settings
    private lateinit var models: ModelManager
    private lateinit var ai: AiRewriter
    private lateinit var controller: RewriteController
    private lateinit var th: KbTheme
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var shifted = false
    private var capsLock = false
    private var symbols = false
    private var panel = 0                 // 0 keys, 1 emoji, 2 clipboard
    private var lastShiftTap = 0L
    private var undoAvail = false
    private var drawerOpen = false
    private var level = FieldLevel.NORMAL
    private var shortcuts: Map<String, String> = emptyMap()
    private val clipItems = ArrayList<String>()       // memory only, never persisted
    private var lastSuggestKey = ""
    private var pulse: ObjectAnimator? = null
    private var popup: PopupWindow? = null

    private var root: LinearLayout? = null
    private var rowsBox: LinearLayout? = null
    private var toolbar: LinearLayout? = null
    private var toolbarScroll: View? = null
    private var drawer: LinearLayout? = null
    private var statusView: TextView? = null
    private var suggestRow: LinearLayout? = null
    private var rewriteChip: TextView? = null
    private var undoChip: TextView? = null

    private val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }
    private val clearStatus = Runnable { statusView?.text = "" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun landscape() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun rowH() = (dp(52) * settings.keyScale / 100 * (if (landscape()) 0.8f else 1f)).toInt()
    private fun ts(base: Float) = base * settings.fontScale / 100f
    private fun animated() = Fx.animated(this, settings)
    private fun radius() = dp(when (settings.keyShape) { 1 -> 20; 2 -> 5; else -> 11 }).toFloat()

    // ---------- lifecycle ----------
    override fun onCreate() {
        super.onCreate()
        settings = Settings(this); models = ModelManager(this); ai = AiRewriter.get(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        controller = RewriteController({ currentInputConnection }, settings, models, ai, this)
        th = Themes.resolve(settings, resources.configuration)
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        pulse?.cancel(); popup?.dismiss(); handler.removeCallbacksAndMessages(null); controller.reset(); super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false      // never take over the screen in landscape

    override fun onCreateInputView(): View {
        th = Themes.resolve(settings, resources.configuration)
        val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(8)) }
        toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(toolbar)
            layoutParams = LinearLayout.LayoutParams(-1, dp(42))
        }
        toolbarScroll = scroll
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(6), dp(4), dp(6), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(2), dp(2), dp(4)) }
        }
        statusView = TextView(this).apply { textSize = 12f; typeface = medium; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), 0); layoutParams = LinearLayout.LayoutParams(-1, dp(18)) }
        suggestRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, dp(34)) }
        rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(scroll); r.addView(drawer); r.addView(statusView); r.addView(suggestRow); r.addView(rowsBox)
        root = r
        applyLayout(); render(); refreshToolbar(); refreshDrawer(); updateSuggestions()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false; capsLock = false; panel = 0
        shifted = (info?.initialCapsMode ?: 0) != 0
        level = SensitiveField.classify(info)
        controller.onNewField(level)
        shortcuts = ShortcutParser.parse(settings.shortcuts)
        if (root != null) {
            th = Themes.resolve(settings, resources.configuration)
            drawerOpen = false; drawer?.visibility = View.GONE
            applyLayout(); render(); refreshToolbar(); refreshDrawer(); updateSuggestions()
            statusView?.text = if (level == FieldLevel.SENSITIVE) "\uD83D\uDD12 AI, suggestions and clipboard off in this field" else ""
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) { popup?.dismiss(); controller.reset(); super.onFinishInputView(finishingInput) }
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); if (level >= 40) ai.release() }
    override fun onLowMemory() { super.onLowMemory(); ai.release() }

    // ---------- RewriteController.Ui ----------
    override fun setStatus(msg: String?) { handler.removeCallbacks(clearStatus); statusView?.text = msg ?: "" }
    override fun setUndoAvailable(b: Boolean) { undoAvail = b; refreshToolbar() }
    override fun setBusy(b: Boolean) {
        val chip = rewriteChip
        pulse?.cancel(); pulse = null
        chip?.alpha = 1f
        if (b && chip != null && animated()) {
            pulse = ObjectAnimator.ofFloat(chip, "alpha", 1f, 0.5f).apply { duration = 600; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
        }
    }
    override fun onRewritten() {
        statusView?.text = "\u2713 Rewritten"
        if (animated()) statusView?.let { Fx.fadeIn(it, dp(4).toFloat(), 220) }
        handler.removeCallbacks(clearStatus); handler.postDelayed(clearStatus, 2500)
    }
    private fun flash(m: String) { statusView?.text = m; handler.removeCallbacks(clearStatus); handler.postDelayed(clearStatus, 3000) }

    // ---------- theme / layout ----------
    private fun applyLayout() {
        val r = root ?: return
        val a = 255 * settings.opacity / 100
        val top = Color.argb(a, Color.red(th.bg), Color.green(th.bg), Color.blue(th.bg))
        val tint = Contrast.mix(th.bg, th.accentFill, if (th.dark) 0.10f else 0.07f)
        r.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, Color.argb(a, Color.red(tint), Color.green(tint), Color.blue(tint))))
        statusView?.setTextColor(th.accentText)
        val w = if (settings.oneHanded == 0) -1 else (resources.displayMetrics.widthPixels * 0.82f).toInt()
        val g = if (settings.oneHanded == 2) Gravity.END else Gravity.START
        for (v in listOf(rowsBox, toolbarScroll, drawer, suggestRow)) {
            val lp = v?.layoutParams as? LinearLayout.LayoutParams ?: continue
            lp.width = w; lp.gravity = g; v?.layoutParams = lp
        }
    }

    // ---------- frosted chips ----------
    private fun glass(selected: Boolean): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat()
        if (selected) { setOrientation(GradientDrawable.Orientation.LEFT_RIGHT); setColors(intArrayOf(th.accentFill, Contrast.mix(th.accentFill, Color.rgb(255, 150, 120), 0.25f))) }
        else { setColor(if (th.dark) Color.argb(40, 255, 255, 255) else Color.argb(150, 255, 255, 255)); setStroke(dp(1), if (th.dark) Color.argb(40, 255, 255, 255) else Color.argb(190, 255, 255, 255)) }
    }

    private fun chip(label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = ts(13f); typeface = medium; gravity = Gravity.CENTER
        setTextColor(if (selected) th.onAccent else th.text)
        setPadding(dp(12), 0, dp(12), 0)
        background = Fx.ripple(glass(selected), th.accentFill)
        alpha = if (enabled) 1f else 0.45f
        layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
        setOnClickListener { feedback(this); onClick() }
    }

    private fun refreshToolbar() {
        val tb = toolbar ?: return
        tb.removeAllViews(); undoChip = null
        val rc = chip("\u2728 Rewrite", true) { controller.rewriteNow() }
        rewriteChip = rc; tb.addView(rc)
        if (undoAvail) { val u = chip("\u21B6 Undo") { controller.undoLast() }; undoChip = u; tb.addView(u)
            if (animated()) { u.scaleX = 0.7f; u.scaleY = 0.7f; Fx.spring(u, 1f, SpringForce.STIFFNESS_MEDIUM, 0.55f) } }
        tb.addView(chip(settings.mode.label + " \u25BE") { toggleDrawer() })
        val cur = Languages.byCode(settings.targetCode)
        val star = if (models.support(cur.code) == Support.EXPERIMENTAL) "*" else ""
        tb.addView(chip("\u2192 ${cur.code.uppercase()}$star \u25BE") { toggleDrawer() })
        tb.addView(chip(if (drawerOpen) "\u2303" else "\u2304") { toggleDrawer() })
    }

    private fun refreshDrawer() {
        val d = drawer ?: return
        d.removeAllViews()
        d.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (th.dark) Color.argb(40, 255, 255, 255) else Color.argb(130, 255, 255, 255))
            setStroke(dp(1), if (th.dark) Color.argb(40, 255, 255, 255) else Color.argb(200, 255, 255, 255))
        }
        fun rowOf(vararg views: View): View = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(LinearLayout(this@C1KeyboardService).apply { views.forEach { addView(it) } })
        }
        d.addView(rowOf(*WritingMode.values().map { m ->
            chip(m.label, selected = m == settings.mode) { settings.modeName = m.name; refreshToolbar(); refreshDrawer() } as View
        }.toTypedArray()))
        d.addView(rowOf(*Languages.all.map { l ->
            val sup = models.support(l.code)
            val ok = models.installedFile() == null && l.code == "en" || sup != Support.UNSUPPORTED
            chip(l.native, selected = l.code == settings.targetCode, enabled = ok) {
                if (ok) { settings.targetCode = l.code; refreshToolbar(); refreshDrawer() }
                else flash(if (models.installedFile() == null) "Install a model to use ${l.name}" else "${l.name}: not supported by this model")
            } as View
        }.toTypedArray()))
        val toggles = ArrayList<View>()
        toggles.add(chip(if (settings.aiEnabled) "AI on" else "AI off", settings.aiEnabled) {
            settings.aiEnabled = !settings.aiEnabled; if (!settings.aiEnabled) controller.disableNow(); refreshDrawer()
        })
        toggles.add(chip(if (settings.autoRewrite) "Auto on" else "Auto off", settings.autoRewrite) {
            settings.autoRewrite = !settings.autoRewrite; if (!settings.autoRewrite) controller.cancelPending(); refreshDrawer()
        })
        toggles.add(chip(if (settings.privacyMode) "\uD83D\uDD12 Private" else "Private off", settings.privacyMode) {
            settings.privacyMode = !settings.privacyMode; if (settings.privacyMode) controller.cancelPending(); refreshDrawer()
        })
        toggles.add(chip("\uD83D\uDE0A") { panel = if (panel == 1) 0 else 1; render() })
        if (settings.clipboardHistory) toggles.add(chip("\uD83D\uDCCB") { panel = if (panel == 2) 0 else 2; render() })
        toggles.add(chip("\u2699 Settings") { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        d.addView(rowOf(*toggles.toTypedArray()))
    }

    private fun toggleDrawer() {
        val d = drawer ?: return
        drawerOpen = !drawerOpen
        refreshToolbar()
        if (!animated()) { d.visibility = if (drawerOpen) View.VISIBLE else View.GONE; d.layoutParams.height = -2; d.requestLayout(); return }
        if (drawerOpen) {
            d.measure(View.MeasureSpec.makeMeasureSpec(resources.displayMetrics.widthPixels, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            val target = d.measuredHeight
            d.layoutParams.height = 0; d.visibility = View.VISIBLE; d.alpha = 0f
            d.animate().alpha(1f).setDuration(180).start()
            Fx.animateHeight(d, 0, target, 180) { d.layoutParams.height = -2; d.requestLayout() }
        } else {
            val from = d.height
            d.animate().alpha(0f).setDuration(120).start()
            Fx.animateHeight(d, from, 0, 140) { d.visibility = View.GONE; d.layoutParams.height = -2; d.alpha = 1f }
        }
    }

    // ---------- suggestions ----------
    private fun currentWord(before: String): String = before.takeLastWhile { it.isLetter() || it == '\'' }

    private fun updateSuggestions() {
        val row = suggestRow ?: return
        if (!settings.suggestions || level != FieldLevel.NORMAL || panel != 0) { row.removeAllViews(); lastSuggestKey = ""; return }
        val before = currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: return
        val word = currentWord(before)
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (word.length >= 2) {
            for (c in Dictionary.complete(word)) {
                val shown = if (word[0].isUpperCase()) c.replaceFirstChar { it.uppercaseChar() } else c
                items.add(shown to { currentInputConnection?.deleteSurroundingText(word.length, 0); commit("$shown ") })
            }
        }
        val key = (if (word.isNotEmpty()) word else before.trimEnd().takeLastWhile { it.isLetter() }).lowercase()
        EmojiData.keywords[key]?.let { e -> items.add(e to { commit(e) }) }
        val shownItems = items.take(4)
        val sig = shownItems.joinToString("|") { it.first }
        if (sig == lastSuggestKey) return
        lastSuggestKey = sig
        row.removeAllViews()
        for ((label, act) in shownItems) {
            row.addView(TextView(this).apply {
                text = label; textSize = ts(15f); typeface = medium; gravity = Gravity.CENTER; setTextColor(th.text)
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
                background = Fx.ripple(GradientDrawable().apply { setColor(Color.TRANSPARENT) }, th.accentFill)
                setOnClickListener { feedback(this); act() }
            })
        }
        if (animated() && shownItems.isNotEmpty()) Fx.fadeIn(row, 0f, 120)
    }

    // ---------- clipboard (memory only; off by default) ----------
    private fun captureClip() {
        if (!settings.clipboardHistory || settings.privacyMode || level == FieldLevel.SENSITIVE) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (cm.primaryClipDescription?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: return
        if (t.isEmpty() || t.length > 500) return
        clipItems.remove(t); clipItems.add(0, t)
        while (clipItems.size > 20) clipItems.removeAt(clipItems.size - 1)
    }

    // ---------- key rendering ----------
    private val alternates = mapOf('a' to "àáâäãåāæ", 'e' to "èéêëēėę", 'i' to "îïíīìį", 'o' to "ôöòóõøōœ", 'u' to "ûüùúū",
        'c' to "çćč", 'n' to "ñń", 's' to "ßśš", 'y' to "ÿý", 'z' to "žźż", 'l' to "ł", 'd' to "ð")

    private fun render() {
        val box = rowsBox ?: return
        box.removeAllViews()
        lastSuggestKey = ""; updateSuggestions()
        if (panel == 1) { renderEmoji(box); return }
        if (panel == 2) { renderClip(box); return }
        if (!symbols) {
            addRow(box, "qwertyuiop".map { letter(it) })
            addRow(box, "asdfghjkl".map { letter(it) }, side = 0.5f)
            addRow(box, listOf(shiftKey()) + "zxcvbnm".map { letter(it) } + listOf(backspaceKey()))
        } else {
            addRow(box, "1234567890".map { sym(it) })
            addRow(box, "@#$%&-+()/".map { sym(it) })
            addRow(box, listOf(sym('*'), sym('"'), sym('\''), sym(':'), sym(';'), sym('!'), sym('?'), backspaceKey()))
        }
        addRow(box, listOf(
            key(if (symbols) "ABC" else "?123", 1.5f, true) { symbols = !symbols; render() },
            key(",", 1f, true) { commit(",") },
            key("space", 5f, false) { commit(" ") },
            key(".", 1f, true, alts = "\u2026?!;:-'\"") { commit(".") },
            key("\u23CE", 1.5f, true, accent = true) { enter() }))
    }

    private fun panelScroll(box: LinearLayout, content: LinearLayout) {
        box.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, rowH() * 3); addView(content) })
        addRow(box, listOf(key("ABC", 1.5f, true) { panel = 0; render() }, key("space", 5f, false) { commit(" ") }, backspaceKey()))
        if (animated()) Fx.fadeIn(box, dp(6).toFloat(), 160)
    }

    private fun renderEmoji(box: LinearLayout) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((name, list) in EmojiData.categories) {
            col.addView(TextView(this).apply { text = name; textSize = ts(12f); typeface = medium; setTextColor(th.accentText); setPadding(dp(6), dp(4), 0, 0) })
            for (chunk in list.chunked(8)) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (e in chunk) row.addView(TextView(this).apply {
                    text = e; textSize = ts(22f); gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                    setOnClickListener { feedback(this); commit(e) }
                })
                col.addView(row)
            }
        }
        panelScroll(box, col)
    }

    private fun renderClip(box: LinearLayout) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (clipItems.isEmpty()) col.addView(TextView(this).apply { text = "Nothing copied yet. History is kept in memory only."; setTextColor(th.text); setPadding(dp(10), dp(10), dp(10), dp(10)) })
        for (t in clipItems) col.addView(TextView(this).apply {
            text = t.replace('\n', ' '); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(th.text); textSize = ts(14f); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Fx.ripple(glass(false), th.accentFill)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
            setOnClickListener { feedback(this); commit(t) }
        })
        col.addView(chip("Clear history") { clipItems.clear(); render() })
        panelScroll(box, col)
    }

    private fun addRow(box: LinearLayout, keys: List<View>, side: Float = 0f) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, rowH()) }
        if (side > 0) row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, side) })
        keys.forEach { row.addView(it) }
        if (side > 0) row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, side) })
        box.addView(row)
    }

    private fun letter(c: Char): View {
        val up = shifted || capsLock
        val label = if (up) c.uppercaseChar().toString() else c.toString()
        return key(label, 1f, false, alts = alternates[c]) { commit(label); if (shifted && !capsLock) { shifted = false; render() } }
    }
    private fun sym(c: Char) = key(c.toString(), 1f, false) { commit(c.toString()) }
    private fun shiftKey() = key(if (capsLock) "\u21EA" else "\u21E7", 1.5f, true, accent = shifted || capsLock) {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) { capsLock = true; shifted = true } else if (capsLock) { capsLock = false; shifted = false } else shifted = !shifted
        lastShiftTap = now; render()
    }
    private fun backspaceKey() = key("\u232B", 1.5f, true, repeat = true) { backspace() }

    private fun feedback(v: View) {
        if (settings.haptics) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (settings.sound) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, settings.soundVolume / 100f)
    }

    private fun faceFor(accent: Boolean, special: Boolean): KeyFace {
        val rim = if (th.dark) Color.argb(40, 255, 255, 255) else Color.argb(210, 255, 255, 255)
        return when {
            accent -> KeyFace(resources.displayMetrics.density, radius(), Contrast.mix(th.accentFill, Color.rgb(255, 160, 130), 0.22f), th.accentFill,
                Contrast.mix(th.accentFill, Color.BLACK, 0.25f), Contrast.mix(th.accentFill, Color.BLACK, 0.18f), Contrast.mix(th.accentFill, Color.BLACK, 0.28f), rim)
            special -> KeyFace(resources.displayMetrics.density, radius(), Contrast.mix(th.special, Color.WHITE, if (th.dark) 0.06f else 0.5f), th.special,
                Contrast.mix(th.special, Color.BLACK, 0.14f), Contrast.mix(th.special, th.accentFill, 0.3f), Contrast.mix(th.special, th.accentFill, 0.4f), rim)
            else -> KeyFace(resources.displayMetrics.density, radius(), th.key, Contrast.mix(th.key, th.special, 0.45f),
                Contrast.mix(th.key, Color.BLACK, if (th.dark) 0.35f else 0.12f), Contrast.mix(th.key, th.accentFill, 0.25f), Contrast.mix(th.key, th.accentFill, 0.38f), rim)
        }
    }

    private fun showAlternates(anchor: View, alts: String) {
        popup?.dismiss()
        val up = shifted || capsLock
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(th.key); setStroke(dp(1), th.special) }
        }
        val pw = PopupWindow(row, -2, dp(48), false)
        pw.isOutsideTouchable = true; pw.elevation = dp(6).toFloat()
        for (ch in alts) {
            val s = if (up) ch.uppercaseChar().toString() else ch.toString()
            row.addView(TextView(this).apply {
                text = s; textSize = ts(22f); gravity = Gravity.CENTER; setTextColor(th.text)
                layoutParams = LinearLayout.LayoutParams(dp(38), -1)
                setOnClickListener { feedback(this); commit(s); pw.dismiss(); if (shifted && !capsLock) { shifted = false; render() } }
            })
        }
        popup = pw
        try { pw.showAsDropDown(anchor, 0, -(anchor.height + dp(52))) } catch (_: Throwable) { popup = null }
    }

    private fun key(label: String, weight: Float, special: Boolean, accent: Boolean = false, repeat: Boolean = false,
                    alts: String? = null, onPress: () -> Unit): View {
        val face = faceFor(accent, special)
        val tv = TextView(this).apply {
            text = label; gravity = Gravity.CENTER; textSize = ts(if (label.length > 2) 14f else 20f); typeface = medium
            setTextColor(if (accent) th.onAccent else th.text)
            background = face.drawable
            layoutParams = LinearLayout.LayoutParams(0, -1, weight).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
        }
        val repeater = object : Runnable { override fun run() { onPress(); handler.postDelayed(this, 50) } }
        var fired = false
        val longPress = Runnable { fired = true; if (alts != null) { feedback(tv); showAlternates(tv, alts) } }
        val live = animated()
        val damping = if (settings.animLevel == 2) 0.45f else 0.62f
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fired = false
                    face.set(1f)
                    if (live) Fx.spring(v, 0.94f, SpringForce.STIFFNESS_HIGH, 0.9f) else v.scaleX = 0.97f
                    if (alts == null) { feedback(v); onPress(); if (repeat) handler.postDelayed(repeater, 400) }
                    else handler.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeater); handler.removeCallbacks(longPress)
                    if (alts != null && !fired && e.actionMasked == MotionEvent.ACTION_UP) { feedback(v); onPress() }
                    if (live) {
                        Fx.spring(v, 1f, SpringForce.STIFFNESS_MEDIUM, damping)
                        ValueAnimator.ofFloat(1f, 0f).apply { duration = 170; addUpdateListener { face.set(it.animatedValue as Float) }; start() }
                    } else { v.scaleX = 1f; v.scaleY = 1f; face.set(0f) }
                }
            }
            true
        }
        return tv
    }

    // ---------- text actions ----------
    private fun expandShortcut(next: String) {
        if (shortcuts.isEmpty() || level != FieldLevel.NORMAL) return
        if (next.length != 1 || next[0].isLetterOrDigit()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: return
        val w = before.takeLastWhile { it.isLetterOrDigit() }
        if (w.isEmpty()) return
        val exp = shortcuts[w.lowercase()] ?: return
        ic.deleteSurroundingText(w.length, 0); ic.commitText(exp, 1)
    }

    private fun commit(s: String) {
        expandShortcut(s)
        currentInputConnection?.commitText(s, 1)
        controller.onUserEdit(s)
        updateSuggestions()
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        controller.onUserEdit(null)
        handler.post { updateSuggestions() }
    }

    private fun enter() {
        controller.cancelPending()
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val multiline = ((info?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        if (!multiline && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) currentInputConnection?.performEditorAction(action)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }
}
