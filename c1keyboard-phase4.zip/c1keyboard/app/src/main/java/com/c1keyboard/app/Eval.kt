package com.c1keyboard.app

/** On-device quality probe. Automated checks are only coarse; outputs must be reviewed by a human. */
object Eval {
    class Case(val input: String, val mode: WritingMode, val mustAny: List<List<String>>, val mustNot: List<String> = emptyList(), val endsWith: String? = null)
    val cases = listOf(
        Case("me kal tumse milne aaunga", WritingMode.SMART_CASUAL, listOf(listOf("tomorrow"), listOf("meet", "see"))),
        Case("mujhe samajh nahi aaya ki waha kya karna hoga", WritingMode.SMART_CASUAL, listOf(listOf("what"), listOf("not", "don't", "n't"))),
        Case("meri flight 7 baje hai, airport pe 5 baje pahunchna hai", WritingMode.SMART_CASUAL, listOf(listOf("flight"), listOf("7"), listOf("5"), listOf("airport"))),
        Case("Rahul ne bola ki wo kal 3 baje call karega", WritingMode.SMART_CASUAL, listOf(listOf("Rahul"), listOf("3"), listOf("call"))),
        Case("yaar bahut bhookh lagi hai, kuch khane chalein?", WritingMode.SMART_CASUAL, listOf(listOf("hungry", "starving")), endsWith = "?"),
        Case("please send me the report jaldi se", WritingMode.SMART_CASUAL, listOf(listOf("report"), listOf("send"))),
        Case("wo mujhe pasand nahi hai", WritingMode.SMART_CASUAL, listOf(listOf("don't like", "do not like", "dislike", "not a fan", "isn't my"))),
        Case("sir mai kal office nahi aa paunga, tabiyat theek nahi hai", WritingMode.PROFESSIONAL, listOf(listOf("tomorrow"), listOf("office")), mustNot = listOf("yaar")),
        Case("kya tum mujhe 500 rupees udhaar de sakte ho?", WritingMode.SMART_CASUAL, listOf(listOf("500"), listOf("lend", "borrow", "loan")), endsWith = "?"),
        Case("he dont know nothing about this project", WritingMode.ORIGINAL_ENGLISH, listOf(listOf("doesn't", "does not")), mustNot = listOf("dont"))
    )

    fun check(c: Case, out: String): List<String> {
        val fails = ArrayList<String>()
        val o = out.lowercase()
        for (group in c.mustAny) if (group.none { o.contains(it.lowercase()) }) fails.add("missing " + group.joinToString("/"))
        for (n in c.mustNot) if (o.contains(n)) fails.add("contains '$n'")
        if (c.endsWith != null && !out.trim().endsWith(c.endsWith)) fails.add("should end with ${c.endsWith}")
        return fails
    }
}
