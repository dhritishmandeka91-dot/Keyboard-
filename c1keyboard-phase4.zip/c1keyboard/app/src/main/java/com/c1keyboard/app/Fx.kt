package com.c1keyboard.app

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/** Animation + drawable helpers. Everything here is skipped when animations are disabled. */
object Fx {
    /** False when the user chose Off / reduced motion, or the system animator scale is 0. */
    fun animated(ctx: Context, s: Settings): Boolean {
        if (s.reducedMotion || s.animLevel == 0) return false
        val scale = android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        return scale != 0f
    }

    fun spring(v: View, target: Float, stiffness: Float, damping: Float) {
        for (prop in listOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
            SpringAnimation(v, prop).setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping)).start()
        }
    }

    fun fadeIn(v: View, dy: Float = 0f, ms: Long = 180, delay: Long = 0) {
        v.alpha = 0f; v.translationY = dy
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(ms).setInterpolator(DecelerateInterpolator()).start()
    }

    fun animateHeight(v: View, from: Int, to: Int, ms: Long, end: () -> Unit) {
        ValueAnimator.ofInt(from, to).apply {
            duration = ms; interpolator = DecelerateInterpolator()
            addUpdateListener { val lp = v.layoutParams; lp.height = it.animatedValue as Int; v.layoutParams = lp }
            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(a: android.animation.Animator) { end() } })
            start()
        }
    }

    fun ripple(content: android.graphics.drawable.Drawable, color: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(60, Color.red(color), Color.green(color), Color.blue(color))), content, null)
}

/** Glossy keycap: a darker "lip" below a gradient face, so it reads as slightly raised without heavy shadows. */
class KeyFace(density: Float, radiusPx: Float, private val top: Int, private val bottom: Int, lip: Int,
              private val pTop: Int, private val pBottom: Int, rim: Int) {
    private val lipD = GradientDrawable().apply { cornerRadius = radiusPx; setColor(lip) }
    private val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
        cornerRadius = radiusPx; setStroke(Math.max(1, density.toInt()), rim)
    }
    val drawable = LayerDrawable(arrayOf(lipD, face)).also { it.setLayerInset(1, 0, 0, 0, (2 * density).toInt()) }
    fun set(t: Float) { face.setColors(intArrayOf(Contrast.mix(top, pTop, t), Contrast.mix(bottom, pBottom, t))) }
}
