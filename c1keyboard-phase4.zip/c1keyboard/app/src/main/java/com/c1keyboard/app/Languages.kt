package com.c1keyboard.app

enum class WritingMode(val label: String, val instruction: String) {
    SMART_CASUAL("Smart Casual", "natural, friendly, correct everyday English as a fluent native speaker would text it. Contractions are fine. Do not use heavy slang."),
    PROFESSIONAL("Professional", "polished, clear, courteous workplace English suitable for email. Concise, no slang."),
    C1_FLUENT("C1 Fluent", "advanced (CEFR C1 level) fluent English: precise vocabulary, natural collocations, varied sentence structure, fully correct grammar. Do not sound pompous."),
    C2_REFINED("C2 Refined", "highly refined, nuanced English in the style of a very proficient writer (CEFR C2 style): elegant but natural phrasing, exact word choice. Never longer than needed."),
    LITERAL("Literal", "a faithful, near word-for-word rendering that stays as close to the original wording and order as grammar allows."),
    ORIGINAL_ENGLISH("Original English", "the writer's own English. Only fix spelling, grammar, punctuation and capitalisation. Keep their wording and voice.")
}

data class Lang(val code: String, val name: String, val native: String, val rtl: Boolean = false, val latin: Boolean = false)

object Languages {
    val all = listOf(
        Lang("en", "English", "English", latin = true),
        Lang("es", "Spanish", "Español", latin = true),
        Lang("ja", "Japanese", "日本語"),
        Lang("zh-CN", "Simplified Chinese", "简体中文"),
        Lang("zh-TW", "Traditional Chinese", "繁體中文"),
        Lang("fr", "French", "Français", latin = true),
        Lang("ko", "Korean", "한국어"),
        Lang("as", "Assamese", "অসমীয়া"),
        Lang("hi", "Hindi", "हिन्दी"),
        Lang("bn", "Bengali", "বাংলা"),
        Lang("de", "German", "Deutsch", latin = true),
        Lang("ar", "Arabic", "العربية", rtl = true),
        Lang("pt", "Portuguese", "Português", latin = true)
    )
    fun byCode(c: String) = all.firstOrNull { it.code == c } ?: all[0]
}

data class Detection(val code: String, val label: String, val confidence: Float)

/** Heuristic detector (script ranges + small word lists). Not a trained model; short text is unreliable. */
object LanguageDetector {
    private val hinglish = setOf("hai","hain","nahi","nahin","kya","mein","tum","aap","ko","ka","ki","ke","se","ho","hoga","hun","hu","raha","rahi","rahe","kar","karo","karna","bhai","yaar","kal","aaj","abhi","bahut","accha","acha","theek","thik","mujhe","tumhe","kyun","kyu","kaise","lekin","par","aur","toh","bola","bol","chal","chalo","gaya","gayi","wala","wali","mera","meri","tera","teri","apna","kuch","sab","bas","phir","kab","kahan","hum","unko","isko","iska","uska","jaldi","nhi","mai","mujhse","padhai","paisa","ghar","kaam","dost","samajh")
    private val en = setOf("the","and","is","are","to","of","in","that","it","you","for","with","this","have","i","not","be","on","was","but","my","we","will")
    private val es = setOf("el","la","de","que","y","en","los","es","un","una","por","con","para","no","como","pero","estoy","tengo")
    private val fr = setOf("le","la","les","de","des","et","est","un","une","que","pour","pas","je","vous","nous","avec","mais","suis")
    private val de = setOf("der","die","das","und","ist","nicht","ich","du","ein","eine","mit","für","auf","aber","wir","sie")
    private val pt = setOf("o","a","os","as","de","que","e","em","um","uma","para","com","não","mas","estou","você","eu")

    fun detect(text: String): Detection {
        var deva = 0; var beng = 0; var asm = 0; var arab = 0; var hang = 0; var kana = 0; var han = 0; var latin = 0
        for (c in text) {
            val cp = c.code
            when {
                cp in 0x0900..0x097F -> deva++
                cp == 0x09F0 || cp == 0x09F1 -> { asm++; beng++ }
                cp in 0x0980..0x09FF -> beng++
                cp in 0x0600..0x06FF -> arab++
                cp in 0xAC00..0xD7AF || cp in 0x1100..0x11FF -> hang++
                cp in 0x3040..0x30FF -> kana++
                cp in 0x4E00..0x9FFF -> han++
                c.isLetter() && cp < 0x250 -> latin++
            }
        }
        val total = (deva + beng + arab + hang + kana + han + latin).coerceAtLeast(1)
        fun d(code: String, label: String, n: Int) = Detection(code, label, n.toFloat() / total)
        return when {
            hang > 0 && hang >= total / 3 -> d("ko", "Korean", hang)
            kana > 0 -> d("ja", "Japanese", kana + han)
            han > 0 && han >= total / 3 -> d("zh-CN", "Chinese", han)
            arab >= total / 3 && arab > 0 -> d("ar", "Arabic", arab)
            asm > 0 -> d("as", "Assamese", beng)
            beng >= total / 3 && beng > 0 -> d("bn", "Bengali", beng)
            deva >= total / 3 && deva > 0 -> d("hi", "Hindi", deva)
            else -> detectLatin(text)
        }
    }

    private fun detectLatin(text: String): Detection {
        val words = text.lowercase().split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return Detection("und", "Unknown", 0f)
        fun score(s: Set<String>) = words.count { it in s }
        val scores = listOf("hinglish" to score(hinglish), "en" to score(en), "es" to score(es), "fr" to score(fr), "de" to score(de), "pt" to score(pt))
        val best = scores.maxByOrNull { it.second }!!
        if (best.second == 0) return Detection("en", "English (assumed)", 0.2f)
        val hi = score(hinglish); val e = score(en)
        val conf = (best.second.toFloat() / words.size * 2f).coerceAtMost(0.95f)
        return when {
            hi >= 1 && hi >= e / 2 && best.first in listOf("hinglish", "en") -> Detection("hi-Latn", "Hinglish / Hindi in Latin script", conf.coerceAtLeast(0.4f))
            best.first == "en" -> Detection("en", "English", conf)
            else -> Detection(best.first, Languages.byCode(best.first).name, conf)
        }
    }
}
