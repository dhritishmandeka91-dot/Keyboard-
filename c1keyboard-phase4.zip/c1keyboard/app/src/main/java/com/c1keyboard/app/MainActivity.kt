package com.c1keyboard.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** Secondary settings screen: setup, local model, writing, appearance, typing, privacy, diagnostics. */
class MainActivity : Activity() {
    private lateinit var st: Settings
    private lateinit var models: ModelManager
    private lateinit var modelInfo: TextView
    private lateinit var progress: ProgressBar
    private lateinit var cancelBtn: Button
    private lateinit var testResult: TextView
    private var handle: ModelManager.ImportHandle? = null
    private val red = Color.parseColor("#C93F5B")
    private val ink = Color.parseColor("#40202A")
    private val accent = Color.parseColor("#C93F5B")
    private val accent2 = Color.parseColor("#C8405A")
    private lateinit var stepEnable: TextView
    private lateinit var stepSelect: TextView
    private val cards = ArrayList<View>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Settings(this); models = ModelManager(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(24)) }
        val sv = ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#FBF7F4"), Color.parseColor("#FBEEEF")))
            addView(root)
        }
        root.addView(TextView(this).apply { text = "C1 Keyboard"; textSize = 30f; setTextColor(red); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) })
        root.addView(TextView(this).apply { text = "Private, on-device writing assistant"; textSize = 14f; setTextColor(ink); setPadding(0, 0, 0, dp(8)) })

        card(root, "Get started", true) { p ->
            text(p, "Two taps and you're typing. Then open any app and tap a text field.")
            stepEnable = text(p, ""); p.addView(btn("Enable C1 Keyboard") { startActivity(Intent(AndroidSettings.ACTION_INPUT_METHOD_SETTINGS)) })
            stepSelect = text(p, ""); p.addView(btn("Choose C1 Keyboard") { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() })
            p.addView(EditText(this).apply { hint = "Try it here: me kal tumse milne aaunga."; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; setTextColor(ink) })
        }

        card(root, "Local AI model", true) { p ->
            modelInfo = text(p, "")
            progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
            p.addView(progress)
            cancelBtn = btn("Cancel import") { handle?.cancel() }.apply { visibility = View.GONE }
            p.addView(cancelBtn)
            p.addView(btn("Import model file (.task / .bin)") {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 11)
            })
            p.addView(btn("Test model (load + run)") { testModel() })
            p.addView(btn("Run quality probe (10 cases)") { runEval() })
            p.addView(btn("Remove model") { models.remove(); refreshModel() })
            testResult = text(p, "")
            text(p, "Offline indicator: this app has no internet permission, so it cannot send or fetch anything. No model is bundled or downloaded. " +
                "Get a MediaPipe-compatible model yourself (for example a Gemma 3 1B int4 .task file) and import it. Gemma models use the Gemma Terms of Use; " +
                "you must accept them on the host site (Hugging Face / Kaggle) before downloading. Inference speed and memory depend on your phone. Typing works without a model.")
        }

        card(root, "Writing", false) { p ->
            p.addView(spinner(WritingMode.values().map { it.label }, st.mode.ordinal) { st.modeName = WritingMode.values()[it].name })
            val langSp = Spinner(this)
            langSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Languages.all.map { "${it.name} (${it.native}) - ${models.support(it.code).label}" })
            langSp.setSelection(Languages.all.indexOfFirst { it.code == st.targetCode }.coerceAtLeast(0))
            langSp.onItemSelectedListener = sel { i ->
                val l = Languages.all[i]
                if (models.support(l.code) == Support.UNSUPPORTED) {
                    Toast.makeText(this, "${l.name} is not supported by the installed model", Toast.LENGTH_LONG).show()
                    langSp.setSelection(0); st.targetCode = "en"
                } else st.targetCode = l.code
            }
            p.addView(langSp)
            p.addView(sw("AI enabled", st.aiEnabled) { st.aiEnabled = it })
            p.addView(sw("Auto-rewrite finished sentences", st.autoRewrite) { st.autoRewrite = it })
            p.addView(slider("Idle delay before auto-rewrite", 500, 5000, 100, st.debounceMs, { "${it / 1000.0} s" }) { st.debounceMs = it })
        }

        card(root, "Appearance and feel", false) { p ->
            p.addView(spinner(Themes.modes, st.themeMode) { st.themeMode = it })
            text(p, "Theme preset (used when mode is 'Preset'). The first 13 are light themes:")
            p.addView(spinner(Themes.presets.map { it.name }, st.presetIdx) { st.presetIdx = it })
            p.addView(sw("Custom accent colour", st.customAccent != 0) { on -> st.customAccent = if (on) hueColor(st.accentHue) else 0 })
            val swatch = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(14)); setBackgroundColor(hueColor(st.accentHue)) }
            p.addView(swatch)
            p.addView(slider("Accent hue", 0, 359, 1, st.accentHue, { "$it\u00B0" }) { h ->
                st.accentHue = h; swatch.setBackgroundColor(hueColor(h)); if (st.customAccent != 0) st.customAccent = hueColor(h)
            })
            text(p, "Key shape:"); p.addView(spinner(listOf("Rounded", "Pill", "Square"), st.keyShape) { st.keyShape = it })
            text(p, "Animation intensity:"); p.addView(spinner(listOf("Off", "Subtle", "Lively"), st.animLevel) { st.animLevel = it })
            p.addView(sw("Reduced motion", st.reducedMotion) { st.reducedMotion = it })
            p.addView(slider("Key height", 80, 130, 5, st.keyScale, { "$it%" }) { st.keyScale = it })
            p.addView(slider("Font size", 85, 130, 5, st.fontScale, { "$it%" }) { st.fontScale = it })
            p.addView(slider("Keyboard opacity", 60, 100, 5, st.opacity, { "$it%" }) { st.opacity = it })
            text(p, "One-handed mode:"); p.addView(spinner(listOf("Off", "Left", "Right"), st.oneHanded) { st.oneHanded = it })
            p.addView(sw("Haptic feedback", st.haptics) { st.haptics = it })
            p.addView(sw("Key sounds (follows system touch-sound setting)", st.sound) { st.sound = it })
            p.addView(slider("Sound volume", 0, 100, 10, st.soundVolume, { "$it%" }) { st.soundVolume = it })
            text(p, "Animations also stop when Android's animation scale is off. Floating keyboard is not implemented. Changes apply the next time the keyboard opens.")
        }

        card(root, "Typing", false) { p ->
            p.addView(sw("Word and emoji suggestions", st.suggestions) { st.suggestions = it })
            p.addView(sw("Clipboard history (memory only, cleared when the keyboard process ends)", st.clipboardHistory) { st.clipboardHistory = it })
            text(p, "Text shortcuts, one per line as abbreviation=expansion (expand on space or punctuation):")
            val sc = EditText(this).apply { setText(st.shortcuts); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; setTextColor(ink) }
            p.addView(sc)
            p.addView(btn("Save shortcuts") { st.shortcuts = sc.text.toString(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() })
            text(p, "Long-press a letter or the period key for alternates. Not implemented: swipe typing, autocorrect (off on purpose: it would corrupt Hinglish words), voice typing, non-QWERTY layouts.")
        }

        card(root, "Privacy", false) { p ->
            p.addView(sw("Privacy mode (no auto-rewrite, no clipboard capture)", st.privacyMode) { st.privacyMode = it })
            text(p, "Typed text is never logged, stored or sent anywhere. AI, suggestions and clipboard capture are automatically off in password, number, phone, email, URL and payment-like fields.")
        }
        setContentView(sv)
        refreshModel(); refreshSteps()
        if (Fx.animated(this, st)) cards.forEachIndexed { i, c -> Fx.fadeIn(c, dp(14).toFloat(), 260, i * 60L) }
    }

    override fun onResume() { super.onResume(); if (::stepEnable.isInitialized) refreshSteps() }

    private fun refreshSteps() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val selected = AndroidSettings.Secure.getString(contentResolver, AndroidSettings.Secure.DEFAULT_INPUT_METHOD)?.startsWith(packageName) == true
        stepEnable.text = (if (enabled) "\u2713 " else "\u25CB ") + "Step 1: Enable C1 Keyboard"
        stepSelect.text = (if (selected) "\u2713 " else "\u25CB ") + "Step 2: Choose it as your keyboard"
    }

    /** Collapsible frosted-style card; the body fades in when opened. */
    private fun card(parent: LinearLayout, title: String, open: Boolean, build: (LinearLayout) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.argb(235, 255, 255, 255)); setStroke(dp(1), Color.parseColor("#F3DDE0")) }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (open) View.VISIBLE else View.GONE }
        val header = TextView(this).apply {
            textSize = 18f; setTextColor(red); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(0, dp(4), 0, dp(4))
        }
        fun label() { header.text = title + (if (body.visibility == View.VISIBLE) "  \u2303" else "  \u2304") }
        label()
        header.setOnClickListener {
            val show = body.visibility != View.VISIBLE
            body.visibility = if (show) View.VISIBLE else View.GONE
            if (show && Fx.animated(this, st)) Fx.fadeIn(body, dp(6).toFloat(), 180)
            label()
        }
        box.addView(header); box.addView(body); parent.addView(box); cards.add(box)
        build(body)
    }

    private fun hueColor(h: Int) = Color.HSVToColor(floatArrayOf(h.toFloat(), 0.62f, 0.9f))

    private fun refreshModel() {
        val f = models.installedFile(); val ai = AiRewriter.get(this)
        val hw = "RAM: ${models.totalRamBytes() shr 20} MB, free storage: ${models.freeStorageBytes() shr 20} MB"
        modelInfo.text = if (f == null) "No model installed.\n$hw"
        else "Installed: ${f.name} (${f.length() shr 20} MB)\nFamily: ${models.family()}\n$hw\n" +
            "Last load: ${if (ai.lastLoadMs < 0) "n/a" else "${ai.lastLoadMs} ms"}, last rewrite: ${if (ai.lastInferMs < 0) "n/a" else "${ai.lastInferMs} ms"}"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != 11 || res != RESULT_OK) return
        progress.visibility = View.VISIBLE; progress.progress = 0; cancelBtn.visibility = View.VISIBLE
        handle = models.importModel(uri, { d, t -> if (t > 0) progress.progress = (d * 100 / t).toInt() }) { r ->
            progress.visibility = View.GONE; cancelBtn.visibility = View.GONE
            r.onSuccess { Toast.makeText(this, "Model imported. Tap 'Test model'.", Toast.LENGTH_LONG).show() }
             .onFailure { Toast.makeText(this, it.message ?: "Import failed", Toast.LENGTH_LONG).show() }
            refreshModel()
        }
    }

    private fun prompt(text: String, mode: WritingMode) =
        PromptBuilder.build(text, mode, Languages.all[0], LanguageDetector.detect(text), Capabilities.usesGemmaTemplate(models.family()))

    private fun testModel() {
        if (models.installedFile() == null) { testResult.text = "Import a model first."; return }
        testResult.text = "Loading model and running a test..."
        AiRewriter.get(this).submit(prompt("kal meeting hai but mai thoda late aaunga", WritingMode.SMART_CASUAL)) { r ->
            testResult.text = r.fold({ "Model works. Output: " + it.trim().take(200) }, { "Model failed: ${it.javaClass.simpleName}: ${it.message?.take(160)}" })
            refreshModel()
        }
    }

    /** Runs the built-in cases through the real model; shows output + timing for human review. Nothing is stored. */
    private fun runEval() {
        if (models.installedFile() == null) { testResult.text = "Import a model first."; return }
        val sb = StringBuilder("Quality probe (review outputs yourself):\n")
        var pass = 0
        fun step(i: Int) {
            if (i >= Eval.cases.size) { testResult.text = sb.append("\nAutomated checks passed: $pass/${Eval.cases.size}. Passing checks do not prove good English.").toString(); refreshModel(); return }
            val c = Eval.cases[i]
            testResult.text = sb.toString() + "\nRunning ${i + 1}/${Eval.cases.size}..."
            val t0 = SystemClock.elapsedRealtime()
            AiRewriter.get(this).submit(prompt(c.input, c.mode)) { r ->
                val ms = SystemClock.elapsedRealtime() - t0
                val out = r.getOrNull()?.let { PromptBuilder.sanitize(it, c.input, Languages.all[0]) }
                if (out == null) sb.append("\n${i + 1}. ERROR/REJECTED (${ms} ms)\n   in:  ${c.input}\n")
                else {
                    val f = Eval.check(c, out); if (f.isEmpty()) pass++
                    sb.append("\n${i + 1}. ${if (f.isEmpty()) "PASS" else "FAIL " + f.joinToString("; ")} (${ms} ms, ${c.mode.label})\n   in:  ${c.input}\n   out: $out\n")
                }
                step(i + 1)
            }
        }
        step(0)
    }

    private fun sel(f: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { f(i) }
        override fun onNothingSelected(p: AdapterView<*>?) {}
    }
    private fun spinner(items: List<String>, selected: Int, f: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected.coerceIn(0, items.size - 1)); onItemSelectedListener = sel(f)
    }
    private fun slider(label: String, min: Int, max: Int, step: Int, value: Int, fmt: (Int) -> String, f: (Int) -> Unit): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lbl = TextView(this).apply { setTextColor(ink); text = "$label: ${fmt(value)}"; setPadding(0, dp(8), 0, 0) }
        col.addView(lbl)
        col.addView(SeekBar(this).apply {
            this.max = (max - min) / step; progress = ((value - min) / step).coerceIn(0, this.max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { val v = min + p * step; lbl.text = "$label: ${fmt(v)}"; f(v) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        return col
    }
    private fun head(p: LinearLayout, t: String) = p.addView(TextView(this).apply { text = t; textSize = 18f; setTextColor(red); setPadding(0, dp(20), 0, dp(4)) })
    private fun text(p: LinearLayout, t: String) = TextView(this).apply { text = t; setTextColor(ink); textSize = 14f; setPadding(0, dp(4), 0, dp(4)) }.also { p.addView(it) }
    private fun sw(t: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply { text = t; isChecked = on; setTextColor(ink); setOnCheckedChangeListener { _, c -> f(c) } }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, accent2)).apply { cornerRadius = dp(14).toFloat() }, null)
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
        setOnClickListener { f() }
    }
}
