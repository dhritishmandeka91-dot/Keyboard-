package com.c1keyboard.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.File

enum class Support(val label: String) {
    SUPPORTED("supported"), EXPERIMENTAL("experimental, unverified"), UNSUPPORTED("not supported by this model")
}
enum class Family { NONE, GEMMA3_1B, GEMMA_MULTI, UNKNOWN }

/**
 * Capability reporting. A .task file cannot be introspected for language ability, so this is a
 * conservative table keyed on the model filename. It reports what is *claimed*, not measured quality.
 */
object Capabilities {
    fun familyOf(fileName: String?): Family {
        if (fileName == null) return Family.NONE
        val n = fileName.lowercase()
        return when {
            n.contains("gemma") && (n.contains("3-1b") || n.contains("3_1b") || n.contains("31b")) -> Family.GEMMA3_1B
            n.contains("gemma") -> Family.GEMMA_MULTI
            else -> Family.UNKNOWN
        }
    }
    fun supportFor(family: Family, code: String): Support = when (family) {
        Family.NONE -> Support.UNSUPPORTED
        Family.GEMMA3_1B -> if (code == "en") Support.SUPPORTED else Support.UNSUPPORTED
        Family.GEMMA_MULTI -> if (code == "en") Support.SUPPORTED else Support.EXPERIMENTAL
        Family.UNKNOWN -> Support.EXPERIMENTAL
    }
    fun usesGemmaTemplate(f: Family) = f == Family.GEMMA3_1B || f == Family.GEMMA_MULTI
}

class ModelManager(ctx: Context) {
    private val app = ctx.applicationContext
    val settings = Settings(app)
    private val main = Handler(Looper.getMainLooper())
    private val dir = File(app.filesDir, "models").apply { mkdirs() }

    class ImportHandle { @Volatile var cancelled = false; fun cancel() { cancelled = true } }

    fun installedFile(): File? = settings.modelFile?.let { File(dir, it) }?.takeIf { it.exists() }
    fun family(): Family = Capabilities.familyOf(installedFile()?.name)
    fun support(code: String) = Capabilities.supportFor(family(), code)
    fun totalRamBytes(): Long { val mi = ActivityManager.MemoryInfo(); (app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi); return mi.totalMem }
    fun freeStorageBytes(): Long = StatFs(app.filesDir.path).availableBytes

    /** RAM rule of thumb: need total RAM >= 2.5x model file size. Heuristic, not a guarantee. */
    fun ramCheck(sizeBytes: Long): String? =
        if (totalRamBytes() < sizeBytes * 5 / 2) "Not enough RAM: this model needs about ${(sizeBytes * 5 / 2) shr 20} MB total device RAM, device has ${totalRamBytes() shr 20} MB." else null

    fun importModel(uri: Uri, onProgress: (Long, Long) -> Unit, onDone: (Result<File>) -> Unit): ImportHandle {
        val h = ImportHandle()
        Thread {
            var tmp: File? = null
            val r = runCatching {
                val cr = app.contentResolver
                var name = "model.task"; var size = -1L
                cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                name = File(name).name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext == "litertlm") error("'.litertlm' files need LiteRT-LM, which this build does not include. Use a MediaPipe .task or .bin model.")
                if (ext !in listOf("task", "bin", "tflite")) error("Unsupported file type '.$ext'. Choose a MediaPipe .task / .bin model.")
                if (size > 0) {
                    if (freeStorageBytes() < size + size / 20 + (50L shl 20)) error("Not enough free storage (need about ${(size shr 20) + 60} MB).")
                    ramCheck(size)?.let { error(it) }
                }
                tmp = File(dir, "$name.part")
                cr.openInputStream(uri)!!.use { input ->
                    tmp!!.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20); var done = 0L; var last = 0L
                        while (true) {
                            if (h.cancelled) error("Import cancelled.")
                            val n = input.read(buf); if (n < 0) break
                            out.write(buf, 0, n); done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 250) { last = now; main.post { onProgress(done, size) } }
                        }
                    }
                }
                AiRewriter.get(app).release()
                installedFile()?.let { if (it.name != name) it.delete() }
                val dest = File(dir, name); if (dest.exists()) dest.delete()
                if (!tmp!!.renameTo(dest)) error("Could not store model file.")
                settings.modelFile = name
                dest
            }
            if (r.isFailure) tmp?.delete()
            main.post { onDone(r) }
        }.start()
        return h
    }

    fun remove() { AiRewriter.get(app).release(); installedFile()?.delete(); settings.modelFile = null }
}
