package com.c1keyboard.app

import android.os.Handler
import android.os.Looper
import android.view.inputmethod.InputConnection

/**
 * Safe auto/manual rewriting. Guarantees:
 *  - original text is untouched until a validated result arrives;
 *  - a result is applied only if the text before the cursor still ends with exactly the snapshot;
 *  - stale / cancelled / superseded jobs are dropped (job id + cancel token);
 *  - our own replacement never schedules another rewrite (no onUserEdit call, results remembered);
 *  - one-step undo restores the original only if the replaced text is still in place.
 * No typed text is ever logged or persisted.
 */
class RewriteController(
    private val ctxProvider: () -> InputConnection?,
    private val settings: Settings,
    private val models: ModelManager,
    private val ai: AiRewriter,
    private val ui: Ui
) {
    interface Ui { fun setStatus(msg: String?); fun setUndoAvailable(b: Boolean); fun setBusy(b: Boolean); fun onRewritten() }

    private class UndoRec(val original: String, val replaced: String, val restored: String)

    private val h = Handler(Looper.getMainLooper())
    private var jobId = 0
    private var cancelJob: (() -> Unit)? = null
    private var undo: UndoRec? = null
    private var level = FieldLevel.NORMAL
    private var lastWasTerm = false
    private val recentOutputs = LinkedHashSet<String>()
    private var lastKey: String? = null
    private val trigger = Runnable { autoTrigger() }
    private val clearStatus = Runnable { ui.setStatus(null) }

    fun onNewField(l: FieldLevel) { reset(); level = l }

    fun reset() {
        h.removeCallbacks(trigger); jobId++; cancelJob?.invoke(); cancelJob = null
        undo = null; ui.setUndoAvailable(false); ui.setBusy(false); ui.setStatus(null); lastWasTerm = false
    }

    fun cancelPending() { h.removeCallbacks(trigger) }

    /** Immediate "AI off": cancels any running/pending work. */
    fun disableNow() { h.removeCallbacks(trigger); jobId++; cancelJob?.invoke(); cancelJob = null; ui.setBusy(false); ui.setStatus(null) }

    /** Call after every key the user types (never for our own replacements). */
    fun onUserEdit(committed: String?) {
        h.removeCallbacks(trigger)
        if (committed == null) lastWasTerm = false
        else if (committed.isNotBlank()) lastWasTerm = committed.last() in ".!?\u0964"
        if (!canAuto()) return
        h.postDelayed(trigger, if (lastWasTerm) 500L else settings.debounceMs.toLong())
    }

    private fun canAuto() = settings.aiEnabled && settings.autoRewrite && !settings.privacyMode && level == FieldLevel.NORMAL &&
        models.installedFile() != null && models.support(settings.targetCode) != Support.UNSUPPORTED

    private fun autoTrigger() {
        if (!canAuto()) return
        val ic = ctxProvider() ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) return
        if (!ic.getTextAfterCursor(1, 0).isNullOrEmpty()) return          // only when cursor is at the end
        val before = ic.getTextBeforeCursor(400, 0)?.toString() ?: return
        val c = SentenceUtil.lastSentence(before) ?: return
        val words = SentenceUtil.wordCount(c.text)
        if (c.text.length > 300 || SentenceUtil.hasProtectedTokens(c.text)) return
        if (c.complete && words < 3) return
        if (!c.complete && (words < 4 || SentenceUtil.endsDangling(c.text))) return
        if (c.text in recentOutputs) return                                 // already produced by us: no recursion
        if (c.text.all { !it.isLetter() }) return
        start(c.text, selection = false, auto = true)
    }

    fun rewriteNow() {
        if (!settings.aiEnabled) { flash("AI is off"); return }
        if (level == FieldLevel.SENSITIVE) { flash("AI disabled in sensitive fields"); return }
        val ic = ctxProvider() ?: return
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrEmpty()) { if (sel.length > 600) flash("Selection too long") else start(sel, selection = true, auto = false); return }
        val before = ic.getTextBeforeCursor(400, 0)?.toString() ?: return
        val c = SentenceUtil.paragraph(before) ?: run { flash("Nothing to rewrite"); return }
        start(c.text, selection = false, auto = false)
    }

    private fun start(orig: String, selection: Boolean, auto: Boolean) {
        val target = Languages.byCode(settings.targetCode)
        val sup = models.support(target.code)
        if (models.installedFile() == null) { if (!auto) flash("No model installed. Open C1 Keyboard app > Import model"); return }
        if (sup == Support.UNSUPPORTED) { flash("${target.name} is not supported by this model"); return }
        val mode = settings.mode
        val key = "$orig|${mode.name}|${target.code}"
        if (auto && key == lastKey) return                                   // duplicate conversion guard
        lastKey = key
        cancelJob?.invoke()
        val my = ++jobId
        ui.setBusy(true); ui.setStatus("Rewriting\u2026")
        val prompt = PromptBuilder.build(orig, mode, target, LanguageDetector.detect(orig), Capabilities.usesGemmaTemplate(models.family()))
        cancelJob = ai.submit(prompt) { r ->
            if (my != jobId) return@submit
            ui.setBusy(false); ui.setStatus(null)
            r.onSuccess { raw ->
                val out = PromptBuilder.sanitize(raw, orig, target)
                if (out == null) flash("Result rejected, original kept")
                else if (out == orig) flash("No change needed")
                else apply(orig, out, selection)
            }.onFailure { flash(shortError(it)) }
        }
    }

    private fun apply(orig: String, out: String, selection: Boolean) {
        val ic = ctxProvider() ?: return
        if (selection) {
            if (ic.getSelectedText(0)?.toString() != orig) { flash("Text changed, kept as is"); return }
            ic.commitText(out, 1)
            remember(out); setUndo(UndoRec(orig, out, orig)); ui.onRewritten(); return
        }
        val before = ic.getTextBeforeCursor(orig.length + 64, 0)?.toString() ?: return
        val trimmed = before.trimEnd()
        if (!trimmed.endsWith(orig)) { flash("Text changed, kept as is"); return }
        val tail = before.substring(trimmed.length)
        ic.beginBatchEdit()
        ic.deleteSurroundingText(orig.length + tail.length, 0)
        ic.commitText(out + tail, 1)
        ic.endBatchEdit()
        remember(out)
        setUndo(UndoRec(orig, out + tail, orig + tail)); ui.onRewritten()
    }

    private fun remember(out: String) { recentOutputs.add(out); if (recentOutputs.size > 20) recentOutputs.remove(recentOutputs.first()) }
    private fun setUndo(u: UndoRec) { undo = u; ui.setUndoAvailable(true) }

    fun undoLast() {
        val u = undo ?: return
        val ic = ctxProvider() ?: return
        val before = ic.getTextBeforeCursor(u.replaced.length, 0)?.toString()
        if (before == u.replaced) {
            ic.beginBatchEdit(); ic.deleteSurroundingText(u.replaced.length, 0); ic.commitText(u.restored, 1); ic.endBatchEdit()
            remember(u.original); lastKey = null; flash("Restored original")
        } else flash("Can't undo: text changed")
        undo = null; ui.setUndoAvailable(false)
    }

    private fun shortError(t: Throwable): String = when {
        t is IllegalStateException && t.message?.startsWith("No model") == true -> "No model installed"
        t is OutOfMemoryError -> "Out of memory: use a smaller model"
        else -> "AI error: " + (t.javaClass.simpleName.take(40))
    }

    private fun flash(m: String) { ui.setStatus(m); h.removeCallbacks(clearStatus); h.postDelayed(clearStatus, 3500) }
}
