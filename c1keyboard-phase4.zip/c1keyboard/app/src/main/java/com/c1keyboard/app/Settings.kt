package com.c1keyboard.app

import android.content.Context

/** All persisted settings. Contains NO typed text. */
class Settings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("c1_settings", Context.MODE_PRIVATE)
    var aiEnabled: Boolean get() = sp.getBoolean("ai", true); set(v) = sp.edit().putBoolean("ai", v).apply()
    var autoRewrite: Boolean get() = sp.getBoolean("auto", true); set(v) = sp.edit().putBoolean("auto", v).apply()
    var privacyMode: Boolean get() = sp.getBoolean("privacy", false); set(v) = sp.edit().putBoolean("privacy", v).apply()
    var debounceMs: Int get() = sp.getInt("debounce", 1200); set(v) = sp.edit().putInt("debounce", v).apply()
    var modeName: String get() = sp.getString("mode", WritingMode.SMART_CASUAL.name)!!; set(v) = sp.edit().putString("mode", v).apply()
    var targetCode: String get() = sp.getString("target", "en")!!; set(v) = sp.edit().putString("target", v).apply()
    var modelFile: String? get() = sp.getString("model", null); set(v) = sp.edit().putString("model", v).apply()
    val mode: WritingMode get() = runCatching { WritingMode.valueOf(modeName) }.getOrDefault(WritingMode.SMART_CASUAL)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    var themeMode: Int get() = i("themeMode", 0); set(v) = sp.edit().putInt("themeMode", v).apply()
    var presetIdx: Int get() = i("preset", 0); set(v) = sp.edit().putInt("preset", v).apply()
    var customAccent: Int get() = i("accent", 0); set(v) = sp.edit().putInt("accent", v).apply()
    var accentHue: Int get() = i("hue", 345); set(v) = sp.edit().putInt("hue", v).apply()
    var keyScale: Int get() = i("keyScale", 100); set(v) = sp.edit().putInt("keyScale", v).apply()
    var fontScale: Int get() = i("fontScale", 100); set(v) = sp.edit().putInt("fontScale", v).apply()
    var opacity: Int get() = i("opacity", 100); set(v) = sp.edit().putInt("opacity", v).apply()
    var haptics: Boolean get() = b("haptics", true); set(v) = sp.edit().putBoolean("haptics", v).apply()
    var sound: Boolean get() = b("sound", false); set(v) = sp.edit().putBoolean("sound", v).apply()
    var soundVolume: Int get() = i("soundVol", 50); set(v) = sp.edit().putInt("soundVol", v).apply()
    var reducedMotion: Boolean get() = b("reduced", false); set(v) = sp.edit().putBoolean("reduced", v).apply()
    var oneHanded: Int get() = i("oneHanded", 0); set(v) = sp.edit().putInt("oneHanded", v).apply()   // 0 off, 1 left, 2 right
    var suggestions: Boolean get() = b("suggest", true); set(v) = sp.edit().putBoolean("suggest", v).apply()
    var clipboardHistory: Boolean get() = b("clip", false); set(v) = sp.edit().putBoolean("clip", v).apply()
    var shortcuts: String get() = sp.getString("shortcuts", "omw=On my way!\nbrb=Be right back")!!; set(v) = sp.edit().putString("shortcuts", v).apply()
    var keyShape: Int get() = i("keyShape", 0); set(v) = sp.edit().putInt("keyShape", v).apply()      // 0 rounded, 1 pill, 2 square
    var animLevel: Int get() = i("animLevel", 1); set(v) = sp.edit().putInt("animLevel", v).apply()     // 0 off, 1 subtle, 2 lively
}
