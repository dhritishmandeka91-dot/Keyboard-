package com.c1keyboard.app

import android.text.InputType
import android.view.inputmethod.EditorInfo

object SentenceUtil {
    data class Candidate(val text: String, val tail: String, val complete: Boolean)

    private fun isBoundary(s: String, i: Int): Boolean = when (s[i]) {
        '\n', '!', '?', '\u0964' -> true
        '.' -> i == s.length - 1 || s[i + 1].isWhitespace()
        else -> false
    }

    /** The last sentence before the cursor (with trailing whitespace reported separately). */
    fun lastSentence(before: String): Candidate? {
        val body = before.trimEnd()
        if (body.isEmpty()) return null
        val tail = before.substring(body.length)
        var end = body.length
        while (end > 0 && body[end - 1] in ".!?\u0964") end--
        val complete = end < body.length
        if (complete && body.endsWith("..")) return null     // ellipsis = unfinished thought
        if (end == 0) return null
        var start = 0
        for (i in end - 1 downTo 0) if (isBoundary(body, i)) { start = i + 1; break }
        while (start < body.length && body[start].isWhitespace()) start++
        if (start >= body.length) return null
        return Candidate(body.substring(start), tail, complete)
    }

    /** Whole current paragraph before the cursor (manual rewrite). Null if empty or too long. */
    fun paragraph(before: String, maxLen: Int = 400): Candidate? {
        val body = before.trimEnd()
        if (body.isEmpty()) return null
        val t = body.substring(body.lastIndexOf('\n') + 1).trimStart()
        if (t.isEmpty() || t.length > maxLen) return null
        return Candidate(t, before.substring(body.length), body.last() in ".!?\u0964")
    }

    fun wordCount(t: String) = t.trim().split(Regex("\\s+")).count { w -> w.any { it.isLetterOrDigit() } }

    private val danglers = setOf("and","but","so","or","because","the","a","an","to","of","with","if","that","aur","ya","ki","jo","toh","kyunki","lekin","par","ke","ka","se","mein")
    fun endsDangling(t: String): Boolean = t.trim().split(Regex("\\s+")).lastOrNull()?.lowercase()?.trim(',', ';', ':') in danglers

    fun hasProtectedTokens(t: String) = t.contains("http", true) || t.contains("www.", true) || t.contains('@') || t.contains("://")
}

enum class FieldLevel { NORMAL, INCOGNITO, SENSITIVE }

object SensitiveField {
    private val hintWords = listOf("password", "passcode", "pin", "cvv", "cvc", "card", "otp", "upi", "secret", "ssn", "iban", "account number", "security code")
    fun classify(info: EditorInfo?): FieldLevel {
        if (info == null) return FieldLevel.SENSITIVE
        val t = info.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_NULL) return FieldLevel.SENSITIVE
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) return FieldLevel.SENSITIVE
        if (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD) return FieldLevel.SENSITIVE
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME) return FieldLevel.SENSITIVE
        val hint = ((info.hintText?.toString() ?: "") + " " + (info.label?.toString() ?: "")).lowercase()
        if (hintWords.any { hint.contains(it) }) return FieldLevel.SENSITIVE
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || v == InputType.TYPE_TEXT_VARIATION_URI || v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)) return FieldLevel.SENSITIVE
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0) return FieldLevel.INCOGNITO
        return FieldLevel.NORMAL
    }
}
