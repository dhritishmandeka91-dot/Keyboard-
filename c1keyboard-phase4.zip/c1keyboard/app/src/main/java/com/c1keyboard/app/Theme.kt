package com.c1keyboard.app

import android.content.res.Configuration
import android.graphics.Color

class KbTheme(val name: String, val dark: Boolean, val bg: Int, val key: Int, val special: Int, val accent: Int, val text: Int) {
    var onAccent: Int = Color.WHITE
    var accentText: Int = accent       // accent used as TEXT on bg, adjusted for contrast
    var pressed: Int = Color.WHITE
    fun withAccent(a: Int): KbTheme {
        val t = KbTheme(name, dark, bg, key, special, a, text)
        t.finish(); return t
    }
    fun finish(): KbTheme {
        val fixed = Contrast.fixAccent(accent)
        onAccent = fixed.second
        accentFill = fixed.first
        accentText = Contrast.readable(accent, bg, text)
        pressed = Contrast.mix(key, accentFill, 0.35f)
        return this
    }
    var accentFill: Int = accent
}

object Contrast {
    private val DARK = 0xFF2A0F16.toInt()
    private fun r(c: Int) = (c shr 16) and 0xFF
    private fun g(c: Int) = (c shr 8) and 0xFF
    private fun bl(c: Int) = c and 0xFF
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    fun lum(c: Int): Double {
        fun f(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else Math.pow((x + 0.055) / 1.055, 2.4) }
        return 0.2126 * f(r(c)) + 0.7152 * f(g(c)) + 0.0722 * f(bl(c))
    }
    fun ratio(a: Int, b: Int): Double {
        val la = lum(a); val lb = lum(b)
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
    }
    fun mix(a: Int, b: Int, t: Float): Int = rgb(
        (r(a) + (r(b) - r(a)) * t).toInt(),
        (g(a) + (g(b) - g(a)) * t).toInt(),
        (bl(a) + (bl(b) - bl(a)) * t).toInt())
    /** Returns (fill colour, text colour on it) with contrast >= 4.5 (darkens the fill if needed). */
    fun fixAccent(accent: Int): Pair<Int, Int> {
        if (ratio(accent, DARK) >= 4.5) return Pair(accent, DARK)
        var c = accent; var i = 0
        while (ratio(c, Color.WHITE) < 4.5 && i < 40) { c = mix(c, Color.BLACK, 0.06f); i++ }
        return Pair(c, Color.WHITE)
    }
    /** Moves fg toward target until contrast with bg is >= 4.5. */
    fun readable(fg: Int, bg: Int, target: Int): Int {
        var c = fg; var i = 0
        while (ratio(c, bg) < 4.5 && i < 20) { c = mix(c, target, 0.12f); i++ }
        return c
    }
}

object Themes {
    val presets: List<KbTheme> = listOf(
        KbTheme("Pearl Cherry", false, 0xFFFBF7F4.toInt(), 0xFFFFFFFF.toInt(), 0xFFF4E4E2.toInt(), 0xFFD94A63.toInt(), 0xFF40202A.toInt()),
        KbTheme("Cherry Blossom", false, 0xFFFFF5F6.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE3E7.toInt(), 0xFFE8647C.toInt(), 0xFF5A2430.toInt()),
        KbTheme("Rose Quartz", false, 0xFFFDF2F5.toInt(), 0xFFFFFFFF.toInt(), 0xFFF9DCE5.toInt(), 0xFFD9588A.toInt(), 0xFF4A1F33.toInt()),
        KbTheme("Peach Cream", false, 0xFFFFF6EE.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE4D1.toInt(), 0xFFEE8C5C.toInt(), 0xFF5B3317.toInt()),
        KbTheme("Lemon Zest", false, 0xFFFFFCEB.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFF1B8.toInt(), 0xFFE0A800.toInt(), 0xFF4A3A00.toInt()),
        KbTheme("Mint Fresh", false, 0xFFF0FBF6.toInt(), 0xFFFFFFFF.toInt(), 0xFFD3F1E3.toInt(), 0xFF2EAD7D.toInt(), 0xFF1C4A38.toInt()),
        KbTheme("Ocean Breeze", false, 0xFFEEF7FD.toInt(), 0xFFFFFFFF.toInt(), 0xFFD4E9F8.toInt(), 0xFF2F8FD8.toInt(), 0xFF17364F.toInt()),
        KbTheme("Lavender Mist", false, 0xFFF6F2FD.toInt(), 0xFFFFFFFF.toInt(), 0xFFE4DAF7.toInt(), 0xFF8A63D2.toInt(), 0xFF3A2760.toInt()),
        KbTheme("Sky Paper", false, 0xFFF3F6FA.toInt(), 0xFFFFFFFF.toInt(), 0xFFDEE6F0.toInt(), 0xFF4F7CAC.toInt(), 0xFF22303F.toInt()),
        KbTheme("Sand Dune", false, 0xFFFAF5EC.toInt(), 0xFFFFFFFF.toInt(), 0xFFEADFC8.toInt(), 0xFFB7894B.toInt(), 0xFF4A3A22.toInt()),
        KbTheme("Sakura Pink", false, 0xFFFFF0F4.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD9E3.toInt(), 0xFFF06292.toInt(), 0xFF5B2038.toInt()),
        KbTheme("Classic Grey", false, 0xFFF2F2F4.toInt(), 0xFFFFFFFF.toInt(), 0xFFDCDCE0.toInt(), 0xFF6B6F80.toInt(), 0xFF202226.toInt()),
        KbTheme("Matcha", false, 0xFFF4F8EC.toInt(), 0xFFFFFFFF.toInt(), 0xFFDDEBC3.toInt(), 0xFF6E9F2F.toInt(), 0xFF2E4018.toInt()),
        KbTheme("Midnight Cherry", true, 0xFF1E1418.toInt(), 0xFF2C1E24.toInt(), 0xFF3B2830.toInt(), 0xFFFF7A93.toInt(), 0xFFFBE9ED.toInt()),
        KbTheme("Graphite", true, 0xFF1B1C1F.toInt(), 0xFF2A2C31.toInt(), 0xFF383B42.toInt(), 0xFF8AB4F8.toInt(), 0xFFECEDEF.toInt()),
        KbTheme("Forest Night", true, 0xFF111A15.toInt(), 0xFF1C2A22.toInt(), 0xFF28392F.toInt(), 0xFF5FCB8F.toInt(), 0xFFE4F3EA.toInt()),
        KbTheme("Deep Ocean", true, 0xFF0F1822.toInt(), 0xFF192836.toInt(), 0xFF223548.toInt(), 0xFF4DB0FF.toInt(), 0xFFE3EEF9.toInt()),
        KbTheme("Violet Dusk", true, 0xFF17121F.toInt(), 0xFF241B31.toInt(), 0xFF31254A.toInt(), 0xFFB794F6.toInt(), 0xFFEFE8FB.toInt()),
        KbTheme("Ember", true, 0xFF1F1410.toInt(), 0xFF2E2019.toInt(), 0xFF3D2C22.toInt(), 0xFFFF9A5C.toInt(), 0xFFFBEBDD.toInt()),
        KbTheme("Plum Wine", true, 0xFF1E1019.toInt(), 0xFF2D1A27.toInt(), 0xFF3E2535.toInt(), 0xFFE86AA6.toInt(), 0xFFF9E6F0.toInt()),
        KbTheme("Slate", true, 0xFF1A1D22.toInt(), 0xFF272B33.toInt(), 0xFF343A45.toInt(), 0xFF7FA6C9.toInt(), 0xFFE6EBF1.toInt()),
        KbTheme("AMOLED Black", true, 0xFF000000.toInt(), 0xFF141414.toInt(), 0xFF222222.toInt(), 0xFFFF6B88.toInt(), 0xFFF2F2F2.toInt()),
        KbTheme("AMOLED Cherry", true, 0xFF000000.toInt(), 0xFF160D10.toInt(), 0xFF261519.toInt(), 0xFFFF5C7C.toInt(), 0xFFFDE8ED.toInt()),
        KbTheme("AMOLED Cyan", true, 0xFF000000.toInt(), 0xFF101516.toInt(), 0xFF1B2528.toInt(), 0xFF3DD6E0.toInt(), 0xFFE3F8FA.toInt()),
        KbTheme("AMOLED Lime", true, 0xFF000000.toInt(), 0xFF121510.toInt(), 0xFF1E2419.toInt(), 0xFFA5E04B.toInt(), 0xFFEFF9DA.toInt())
    ).map { it.finish() }
    const val LIGHT = 0; const val DARK = 13; const val AMOLED = 22
    val modes = listOf("Light", "Dark", "AMOLED", "System", "Preset")

    fun resolve(s: Settings, cfg: Configuration): KbTheme {
        val idx = when (s.themeMode) {
            0 -> LIGHT; 1 -> DARK; 2 -> AMOLED
            3 -> if ((cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES) DARK else LIGHT
            else -> s.presetIdx.coerceIn(0, presets.size - 1)
        }
        val base = presets[idx]
        return if (s.customAccent != 0) base.withAccent(s.customAccent) else base
    }
}
