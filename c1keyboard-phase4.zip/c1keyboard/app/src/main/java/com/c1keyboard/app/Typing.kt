package com.c1keyboard.app

/** Prefix word suggestions (built-in list, nothing learned or stored), emoji suggestions, text shortcuts. */
object Dictionary {
    private val words = ("the be to of and a in that have it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did said very much really thank thanks please sorry hello hi hey tomorrow today tonight yesterday morning evening afternoon meeting message call send sent receive email phone number address office home school college friend family brother sister mother father love happy sad angry tired hungry busy free late early soon already still always never sometimes maybe probably definitely actually basically important problem question answer help need needs needed wanted wait waiting working worked going gone coming came doing done everything something anything nothing everyone someone anyone before between through during without within against around another different example following information understand understood remember forget forgot sure certain available possible impossible should would could might must shall until while though although however therefore meanwhile together tomorrow weekend monday tuesday wednesday thursday friday saturday sunday january february march april june july august september october november december birthday party dinner lunch breakfast coffee water money payment account report document schedule project deadline presentation conference interview application resume experience company manager colleague customer service product price discount delivery order confirm confirmed cancelled reschedule appointment welcome congratulations appreciate appreciated opportunity regards sincerely best wishes).split(" ").distinct()
    fun complete(prefix: String, max: Int = 3): List<String> {
        val p = prefix.lowercase()
        if (p.length < 2) return emptyList()
        return words.filter { it.startsWith(p) && it != p }.take(max)
    }
}

object EmojiData {
    val keywords = mapOf(
        "happy" to "😊", "khush" to "😊", "smile" to "😊", "love" to "❤️", "pyaar" to "❤️", "pyar" to "❤️", "heart" to "❤️",
        "sad" to "😢", "udaas" to "😢", "cry" to "😭", "angry" to "😠", "gussa" to "😠", "laugh" to "😂", "funny" to "😂", "lol" to "😂",
        "thanks" to "🙏", "thank" to "🙏", "please" to "🙏", "sorry" to "🙏", "congratulations" to "🎉", "party" to "🎉", "birthday" to "🎂",
        "food" to "🍽️", "hungry" to "🍔", "bhookh" to "🍔", "coffee" to "☕", "chai" to "☕", "pizza" to "🍕", "sleep" to "😴", "neend" to "😴",
        "tired" to "😩", "busy" to "⏳", "ok" to "👍", "okay" to "👍", "good" to "👍", "great" to "🌟", "yes" to "✅", "no" to "❌",
        "fire" to "🔥", "money" to "💰", "paisa" to "💰", "home" to "🏠", "ghar" to "🏠", "car" to "🚗", "flight" to "✈️", "phone" to "📱",
        "call" to "📞", "work" to "💼", "office" to "💼", "study" to "📚", "padhai" to "📚", "sun" to "☀️", "rain" to "🌧️", "baarish" to "🌧️",
        "hello" to "👋", "hi" to "👋", "bye" to "👋", "wow" to "😮", "cool" to "😎", "think" to "🤔", "kiss" to "😘", "hug" to "🤗")
    val categories: List<Pair<String, List<String>>> = listOf(
        "Smileys" to "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😋 😛 😜 🤪 🤔 🤨 😐 😑 😶 🙄 😏 😣 😥 😮 🤐 😯 😪 😫 😴 😎 🤓 😕 😟 🙁 😮‍💨 😲 😳 🥺 😦 😧 😨 😰 😢 😭 😱 😖 😞 😓 😩 😤 😡 😠 🤬",
        "Gestures" to "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 👋 🤝 🙏 👏 🙌 💪 🫶 ✍️ 💅",
        "Hearts" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 ✨ 🌟 ⭐ 🔥 🎉 🎊 🎂 🎁",
        "Things" to "☕ 🍕 🍔 🍟 🍜 🍛 🍰 🍎 🍌 🥭 🚗 ✈️ 🚆 🏠 🏢 📱 💻 📞 📧 📚 💼 💰 ⏰ 📅 ☀️ 🌧️ 🌙 ⚡ 🌈 ✅ ❌ ⚠️ ❓ ❗"
    ).map { it.first to it.second.split(" ") }
}

object ShortcutParser {
    fun parse(text: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (line in text.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = line.substring(0, i).trim().lowercase(); val v = line.substring(i + 1).trim()
            if (k.isNotEmpty() && v.isNotEmpty() && !k.contains(' ')) m[k] = v
        }
        return m
    }
}
