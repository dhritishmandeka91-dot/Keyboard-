package com.c1keyboard.app

import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test fun sentenceWithPeriod() {
        val c = SentenceUtil.lastSentence("Hello there. me kal tumse milne aaunga.")!!
        assertEquals("me kal tumse milne aaunga.", c.text); assertTrue(c.complete)
    }
    @Test fun trailingSpaceKeptAsTail() {
        val c = SentenceUtil.lastSentence("kal milte hain yaar. ")!!
        assertEquals("kal milte hain yaar.", c.text); assertEquals(" ", c.tail)
    }
    @Test fun idleSentenceIsIncomplete() { assertFalse(SentenceUtil.lastSentence("mujhe samajh nahi aaya")!!.complete) }
    @Test fun decimalIsNotBoundary() { assertEquals("price is 3.5 rupees", SentenceUtil.lastSentence("price is 3.5 rupees")!!.text) }
    @Test fun ellipsisIsUnfinished() { assertNull(SentenceUtil.lastSentence("wait...")) }
    @Test fun danglingWords() { assertTrue(SentenceUtil.endsDangling("I will go but")); assertFalse(SentenceUtil.endsDangling("I will go home")) }
    @Test fun protectedTokens() { assertTrue(SentenceUtil.hasProtectedTokens("mail me at a@b.com")); assertFalse(SentenceUtil.hasProtectedTokens("hello world")) }
    @Test fun detectsHinglish() { assertEquals("hi-Latn", LanguageDetector.detect("mujhe kal office jana hai yaar").code) }
    @Test fun detectsEnglish() { assertEquals("en", LanguageDetector.detect("I will see you at the office tomorrow").code) }
    @Test fun detectsScripts() {
        assertEquals("hi", LanguageDetector.detect("मुझे कल आना है").code)
        assertEquals("ko", LanguageDetector.detect("안녕하세요").code)
        assertEquals("as", LanguageDetector.detect("ৰমেশ আহিব").code)
        assertEquals("ar", LanguageDetector.detect("مرحبا بك").code)
    }
    @Test fun sanitizeStripsQuotesAndTokens() {
        assertEquals("I'll see you tomorrow.", PromptBuilder.sanitize("\"I'll see you tomorrow.\"<end_of_turn>", "kal milte hain", Languages.all[0]))
    }
    @Test fun sanitizeRejectsMissingNumber() { assertNull(PromptBuilder.sanitize("I'll be there soon.", "mai 5 baje aaunga", Languages.all[0])) }
    @Test fun sanitizeRejectsEmptyOrHuge() {
        assertNull(PromptBuilder.sanitize("   ", "hello there", Languages.all[0]))
        assertNull(PromptBuilder.sanitize("x".repeat(500), "hi", Languages.all[0]))
    }
    @Test fun capabilityTable() {
        assertEquals(Support.UNSUPPORTED, Capabilities.supportFor(Family.NONE, "en"))
        assertEquals(Support.SUPPORTED, Capabilities.supportFor(Family.GEMMA3_1B, "en"))
        assertEquals(Support.UNSUPPORTED, Capabilities.supportFor(Family.GEMMA3_1B, "as"))
        assertEquals(Support.EXPERIMENTAL, Capabilities.supportFor(Family.GEMMA_MULTI, "as"))
        assertEquals(Family.GEMMA3_1B, Capabilities.familyOf("gemma3-1b-it-int4.task"))
    }
    @Test fun contrastPresetsAndCustomAccent() {
        for (t in Themes.presets) {
            assertTrue(t.name, Contrast.ratio(t.text, t.key) >= 4.5)
            assertTrue(t.name, Contrast.ratio(t.onAccent, t.accentFill) >= 4.5)
        }
        for (h in 0 until 360 step 15) {
            val c = 0xFF000000.toInt() or (h * 0x010101 and 0xFFFFFF)
            val f = Contrast.fixAccent(c); assertTrue(Contrast.ratio(f.first, f.second) >= 4.5)
        }
    }
    @Test fun shortcutParsing() { assertEquals(mapOf("omw" to "On my way!"), ShortcutParser.parse("omw=On my way!\nbad line\nx y=no")) }
    @Test fun dictionaryComplete() { assertTrue(Dictionary.complete("tomo").contains("tomorrow")) }
    @Test fun twentyFourPresets() { assertTrue(Themes.presets.size >= 20) }
}
